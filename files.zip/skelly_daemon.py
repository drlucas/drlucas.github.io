#!/usr/bin/env python3
"""
skelly_daemon.py - holds ONE persistent BLE connection to the SVI Animated Skelly
and accepts quick commands over a local HTTP port, so FPP never has to scan/connect.

Endpoints (all GET, localhost only):
    /play/N      play file serial N (restarts it if something is playing)
    /stop        pause whatever is playing
    /volume/N    set volume 0-100
    /status      connection + playing state
    /wake        force a reconnect attempt now

Protocol credit: https://github.com/tinkertims/SVI-Ultra-Skelly-Tools
"""
import asyncio
import logging

from bleak import BleakClient, BleakScanner

ADDRESS = "C3:93:D4:E0:63:18"  # your skelly's MAC
HOST, PORT = "127.0.0.1", 8765

WRITE_UUID = "0000ae01-0000-1000-8000-00805f9b34fb"
NOTIFY_UUID = "0000ae02-0000-1000-8000-00805f9b34fb"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
log = logging.getLogger("skelly")


# ---------------------------------------------------------------- protocol
def crc8(data: bytes) -> str:
    crc = 0
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc >> 1) ^ 0x8C) if (crc & 1) else (crc >> 1)
    return f"{crc:02X}"


def build_cmd(tag: str, payload: str = "00") -> bytes:
    base = "AA" + tag + payload
    if len(payload) < 16:
        base += "0" * (16 - len(payload))
    return bytes.fromhex(base + crc8(bytes.fromhex(base)))


def int_to_hex(n: int, byte_len: int) -> str:
    return f"{n:0{byte_len * 2}X}"


def play_or_pause_file(serial: int, action: int) -> bytes:
    return build_cmd("C6", int_to_hex(serial, 2) + int_to_hex(action, 1))


def set_volume(vol: int) -> bytes:
    return build_cmd("FA", int_to_hex(vol, 1))


# ---------------------------------------------------------------- skelly link
class Skelly:
    def __init__(self, address: str):
        self.address = address
        self.client = None
        self.connected = asyncio.Event()
        self.wake = asyncio.Event()
        self.lock = asyncio.Lock()
        self.playing = False
        self.serial = 0

    def on_notify(self, _sender, data: bytearray):
        h = data.hex().upper()
        if h.startswith("FEDC"):
            return  # keepalive chatter
        if h.startswith("BBC6"):
            self.serial = int(h[4:8], 16)
            self.playing = bool(int(h[8:10], 16))
            log.info("device: file %d playing=%s", self.serial, self.playing)
        else:
            log.info("device: %s", h)

    async def connection_loop(self):
        """Connect, stay connected, reconnect forever."""
        while True:
            disc = asyncio.Event()
            try:
                log.info("scanning for %s ...", self.address)
                dev = await BleakScanner.find_device_by_address(self.address, timeout=10.0)
                if dev is None:
                    log.info("not found (powered off, out of range, or another app holds it)")
                    await self._pause(5)
                    continue

                def _on_disc(_c):
                    log.info("disconnected")
                    disc.set()

                async with BleakClient(dev, disconnected_callback=_on_disc, timeout=20.0) as client:
                    self.client = client
                    await client.start_notify(NOTIFY_UUID, self.on_notify)
                    self.connected.set()
                    log.info("connected")
                    while not disc.is_set() and client.is_connected:
                        await asyncio.sleep(1.0)
            except Exception as e:
                log.info("connection error: %s", e)
            finally:
                self.connected.clear()
                self.client = None
                self.playing = False
            await self._pause(3)

    async def _pause(self, seconds):
        """Sleep, but let /wake cut it short."""
        try:
            await asyncio.wait_for(self.wake.wait(), seconds)
        except asyncio.TimeoutError:
            pass
        self.wake.clear()

    async def send(self, cmd: bytes):
        if not self.connected.is_set():
            try:
                await asyncio.wait_for(self.connected.wait(), 8.0)
            except asyncio.TimeoutError:
                raise RuntimeError("skelly not connected")
        async with self.lock:
            await self.client.write_gatt_char(WRITE_UUID, cmd)

    async def play(self, serial: int):
        if self.playing:  # restart cleanly instead of being ignored
            await self.send(play_or_pause_file(self.serial or serial, 0))
            await asyncio.sleep(0.3)
        await self.send(play_or_pause_file(serial, 1))

    async def stop(self):
        await self.send(play_or_pause_file(self.serial or 1, 0))


skelly = Skelly(ADDRESS)


# ---------------------------------------------------------------- tiny HTTP API
async def route(path: str):
    parts = [p for p in path.split("?")[0].split("/") if p]
    cmd = parts[0] if parts else "status"
    arg = parts[1] if len(parts) > 1 else None

    if cmd == "play" and arg and arg.isdigit() and 1 <= int(arg) <= 255:
        await skelly.play(int(arg))
        return 200, f"OK play {arg}"
    if cmd == "stop":
        await skelly.stop()
        return 200, "OK stop"
    if cmd == "volume" and arg and arg.isdigit() and 0 <= int(arg) <= 100:
        await skelly.send(set_volume(int(arg)))
        return 200, f"OK volume {arg}"
    if cmd == "wake":
        skelly.wake.set()
        return 200, "OK reconnecting"
    if cmd == "status":
        return 200, (f"connected={skelly.connected.is_set()} "
                     f"playing={skelly.playing} file={skelly.serial}")
    return 404, "unknown command"


async def handle(reader, writer):
    try:
        line = await asyncio.wait_for(reader.readline(), 5.0)
        parts = line.decode(errors="ignore").split()
        path = parts[1] if len(parts) > 1 else "/"
        while True:  # drain headers
            h = await asyncio.wait_for(reader.readline(), 5.0)
            if h in (b"\r\n", b"\n", b""):
                break
        status, body = await route(path)
    except Exception as e:
        status, body = 503, f"ERROR {e}"
    log.info("%s -> %s %s", path if 'path' in locals() else '?', status, body)
    payload = (body + "\n").encode()
    writer.write(
        f"HTTP/1.1 {status} X\r\nContent-Type: text/plain\r\n"
        f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode() + payload
    )
    try:
        await writer.drain()
    finally:
        writer.close()


async def main():
    server = await asyncio.start_server(handle, HOST, PORT)
    log.info("listening on http://%s:%d", HOST, PORT)
    async with server:
        await asyncio.gather(server.serve_forever(), skelly.connection_loop())


if __name__ == "__main__":
    asyncio.run(main())
