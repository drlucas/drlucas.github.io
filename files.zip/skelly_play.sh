#!/bin/bash
# Tiny client for skelly_daemon.py. Use from an FPP "Script" playlist entry.
#   skelly_play.sh 1       -> play file 1
#   skelly_play.sh stop    -> stop
#   skelly_play.sh status  -> show state
# Logs to /home/fpp/media/logs/skelly_play.log so you can see what happened.
ARG="${1:-status}"
if [[ "$ARG" =~ ^[0-9]+$ ]]; then URL="http://127.0.0.1:8765/play/$ARG"; else URL="http://127.0.0.1:8765/$ARG"; fi
RESULT=$(curl -s -m 10 "$URL" || echo "curl failed (is the skelly service running?)")
echo "$(date '+%F %T') $ARG -> $RESULT" >> /home/fpp/media/logs/skelly_play.log
echo "$RESULT"
